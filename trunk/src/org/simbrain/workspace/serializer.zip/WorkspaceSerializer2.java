package org.simbrain.workspace;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

public class WorkspaceSerializer2 {
    private final Workspace workspace;
    
    public WorkspaceSerializer2(Workspace workspace) {
        this.workspace = workspace;
    }
    
    public void serialize(OutputStream output) throws IOException {
        TableOfContents contents = new TableOfContents();
        WorkspaceComponentSerializer componentSerializer = new WorkspaceComponentSerializer();
        
        for (WorkspaceComponent<?> component : workspace.getComponentList()) {
            TableOfContents.Component entry = new TableOfContents.Component();
            contents.components.add(entry);
            
            String name = component.getName();
            FileOutputStream stream = new FileOutputStream(name);
            
            entry.className = component.getClass().getName();
            entry.id = componentSerializer.serializeComponent(component, stream);
            entry.uri = name;
            
            stream.flush();
            stream.close();
        }
        
        contents.toXml(output);
    }
    
    public void deserialize(InputStream stream) throws IOException {
        ZipInputStream zip = new ZipInputStream(stream);
        TableOfContents contents = null;
        WorkspaceComponentSerializer componentSerializer = new WorkspaceComponentSerializer();
        
        for (ZipEntry entry; (entry = zip.getNextEntry()) != null;) {
            String name = entry.getName();
            System.out.println("entry: " + name);
            
            if ("contents.xml".equals(name)) {
                contents = (TableOfContents) TableOfContents.xstream().fromXML(
                    new SubsetInputStream(zip, entry.getSize()));
                
                System.out.println("entry.getSize(): " + entry.getSize());
                
                for (TableOfContents.Component component : contents.components) {
                    System.out.println("component: " + component.uri);
                }
            } else {
                TableOfContents.Component component = contents.getComponent(name);
                
                WorkspaceComponent wc = componentSerializer.deserializeComponent(
                    component.className, new SubsetInputStream(zip, entry.getSize()), "name", null);
                
                workspace.addWorkspaceComponent(wc);
            }
        }
    }
    
    private class SubsetInputStream extends InputStream {
        int index = 0;
        final InputStream stream;
        final long length;
        
        SubsetInputStream(InputStream stream, long length) {
            this.stream = stream;
            this.length = length;
        }

        @Override
        public int read() throws IOException {
            if (index++ < length) return stream.read();
            else return -1;
        }
    }
    
    static class TableOfContents {
        SimbrainDesktop desktop;
        ArrayList<Component> components = new ArrayList<Component>();
        ArrayList<Coupling> couplings;
        
        Component getComponent(String uri) {
            for (Component component : components) {
                if (component.uri.equals(uri)) return component;
            }
            
            return null;
        }
        
        static class SimbrainDesktop {
            String uri;
        }
        
        static class Component {
            String className;
            String uri;
            int id;
            ArrayList<DesktopComponent> desktopComponents;
            
            class DesktopComponent {
                String uri;
            }
        }
        
        static class Coupling {
            int source;
            int target;
        }
        
        private void toXml(OutputStream stream) {
            xstream().toXML(this, stream);
        }
        
        private static XStream xstream() {
            XStream xstream = new XStream(new DomDriver());
            
            xstream.alias("Workspace", TableOfContents.class);
            xstream.alias("Component", Component.class);
            xstream.alias("Coupling", Coupling.class);
            xstream.alias("DesktopComponent", Component.DesktopComponent.class);
            
            xstream.addImplicitCollection(TableOfContents.class, "components", Component.class);
            xstream.addImplicitCollection(TableOfContents.class, "couplings", Coupling.class);
            xstream.addImplicitCollection(Component.class, "desktopComponents");
            
            return xstream;
        }
    }
}
